# COVID19-India API Index

## A detailed documentation of all the APIs. The logic extends to CSV files wherever the corresponding CSV endpoints are provided

- [raw_data{n}.json](rawdata.md)
- [v4/min/data.min.json](v4_data.md)
- [v4/min/timeseries.min.json](timeseries.min.md)
