# Browser extensions using this API

## _Both Chrome and Firefox:_

- [Covid-19 Tracker](https://coronatrends.live) (by [@akanshgulati](https://github.com/akanshgulati))

## _Firefox Extension:_

- [CovidTrack India](https://addons.mozilla.org/en-US/firefox/addon/covidtrack-india/) (by [@mdb571](https://github.com/mdb571))
