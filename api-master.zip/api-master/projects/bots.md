# Bots using this API

## _Discord bots:_

- [Indian Bot | भारतीय स्वायत्तसेवा](https://discord.com/oauth2/authorize?scope=bot&client_id=583897295267954697&permissions=1342565446) (by [gouenji-shuuya](https://github.com/gouenji-shuuya))

- [COVID-19 India Bot](https://discordapp.com/oauth2/authorize?&client_id=723409740083757166&scope=bot&permissions=8) (by [vj1224](https://github.com/VJ1224))

---

## _Reddit bots:_

- [COVID-19 Reddit BOT](https://github.com/parshnt/covid-19-bot) (by [@parshnt](https://github.com/parshnt))

---

## _Telegram bots:_

- [CoVID19 India Patients Analyzer and Alerts](https://github.com/xsreality/covid19)

- [CovidBot: CoVID19 Live Stats Chatbot](https://github.com/Tele-Bots/CovidBot) (by [@gurrrung](https://github.com/gurrrung))

- [covid19indiatracker_bot](https://github.com/cibinjoseph/covid19indiatracker_bot)

- [INDIA COVID-19 Google Map TRACKER](https://goo.gl/maps/U32Ex1gWQxmc6Aot8) (by [@jeethesh-kotian](https://github.com/jeethesh-kotian))

- [Covid19WorldStats](https://github.com/ravindraten/Covid19WorldStats) (by [@RavindraNayak](https://github.com/ravindraten))

- [Covid19India Stats & News] (<https://t.me/Covid19trackerindiagj27_bot>) (by [@akhiltrivedi])

- [Karnataka COVID 19 Counts](https://t.me/KarCovid19Bot) (by [@AbhishekPednekar84](https://github.com/AbhishekPednekar84/covid19-kar-bot))

---

## _Twitter bots:_

- [COVID-19 Twitter BOT](https://twitter.com/covidapp_in) (by Prabhakar Thota [@myinnos](https://github.com/myinnos))
