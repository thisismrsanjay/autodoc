# Analysis projects using this API

- [Data Analysis : India - District & State](https://docs.google.com/spreadsheets/d/1yS8x7IrlWLdtgM6UUPm2YN8lLRmRYJKm-4Wax-8EBuI/edit?usp=sharing)
  - By: [@Ankan_Plotter](https://t.me/Ankan_Plotter)

---

- [Stats and viz in Google Data Studio](https://tinyurl.com/covid19indiadashboard)
  - By: [@veeyeskay](https://t.me/veeyeskay)

---

- [R-naught stats for India](https://www.rt-india.live/)
  - By: [@rohit](https://t.me/rohitxsh)

---

- [Covid19 India Predictions and Stats](https://ncov19stats.herokuapp.com)
  - By: [Naveen](https://www.github.com/naveensaigit)

---

- [Covid 19 stats and Reproduction value (Rt)](https://www.rtindia.org)
  - By: [Laksh](http://github.com/lakshmatai), Yash and [Nilesh](https://github.com/nilesh304)
